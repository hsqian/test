#include "motor.h"


void Motor_PWM_Init(void)
{
    mypwm_init(TIM_5,TIM_5_CH1_A00,0,6400,0);//����
    gpio_init( A1, GPO, 0, GPO_PUSH_PULL);
    mypwm_init(TIM_5,TIM_5_CH3_A02,0,6400,0);//����
    gpio_init( A3, GPO, 1, GPO_PUSH_PULL);
}

//�޷�����
void Limit(int *motorA,int *motorB)
{
    if( *motorA>PWM_MAX)*motorA=PWM_MAX;
    if( *motorA<PWM_MIN)*motorA=PWM_MIN;

    if( *motorB>PWM_MAX)*motorB=PWM_MAX;
    if( *motorB<PWM_MIN)*motorB=PWM_MIN;
}


//����ֵ����
int GFP_abs(int p)
{
    int q;
    q=p>0?p:(-p);
    return q;
}


//��ֵ����
/*pid���������pwmֵ*/
void Load(int moto1,int moto2)
{
    if (moto1>0) Linh;
    else 				 Linl;
    mypwm_duty_updata(TIM_5,TIM_5_CH1_A00,GFP_abs(moto1));

    if (moto2>0) Rinh;
    else 				 Rinl;
    mypwm_duty_updata(TIM_5,TIM_5_CH3_A02,GFP_abs(moto2));
}
#ifndef __NOMALIZE_H
#define __NOMALIZE_H

#include "headfile.h"

float nomal(float data, int ADCGET_MAX);

#define LLRR_MAX 3200
#define LMRM_MAX 3150
#define LR_MAX   3180
#define NUM_MAX 100
#define NUM_MIN 0

#endif
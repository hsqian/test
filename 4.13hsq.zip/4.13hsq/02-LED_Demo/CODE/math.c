#include "math.h"

float err_get(float adc_L,float adc_LM,float adc_RM,float adc_R,float A,float B)
{
    float temp_add1=0,temp_add2=0,temp_sub1=0,temp_sub2=0,err_back;
    temp_sub1=adc_L-adc_R;
    temp_sub2=adc_LM-adc_RM;
    temp_add1=adc_L+adc_R;
    temp_add2=adc_LM+adc_RM;

    err_back=(A*temp_sub1+B*temp_sub2)/(A*temp_add1+B*temp_add2);
    return err_back;
}

//int develop(int *buff,int len)
//{
//	int i,temp[i];
//	for(i=0;i<len;i++)
//	{
//		temp[i]=buff[i+1]-buff[i];
//	}
//	if(temp[i])
//}
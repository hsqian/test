#ifndef __TIM_H
#define __TIM_H

#include "headfile.h"

void my_timer(void);

#endif
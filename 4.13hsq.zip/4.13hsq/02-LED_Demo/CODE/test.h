#ifndef __TEST_H
#define __TEST_H

#include "headfile.h"

void test(int TESTx);

//struct test
//{
//}
#endif
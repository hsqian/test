#include "scheduler.h"

int a;

volatile uint64_t systime_ms = 0;

/********************************************************************************
* Routine: Loop_1000Hz
* Description:
* Param: NULL
* Return: NULL
* Notes:
**********************************************************************************/
static void Loop_1000Hz(void)
{

}

/********************************************************************************
* Routine: Loop_500Hz
* Description:
* Param: NULL
* Return: NULL
* Notes:
**********************************************************************************/
static void Loop_500Hz(void)
{

    Encoder_Left  =  Encoder_Read(4);                                 //===��ȡ��������ֵ							 //Ϊ�˱�֤M�����ٵ�ʱ���׼�����ȶ�ȡ����������
    Encoder_Right =  -Encoder_Read(3);
	
	
    Get_RC();
    Kinematic_Analysis(Velocity,Turn);     															//С���˶�ѧ����
    Motor_A=Incremental_PI_A(Encoder_Left, Target_A);                   //===�ٶȱջ����Ƽ�����A����PWM
    Motor_B=Incremental_PI_B(Encoder_Right,Target_B);                  //===�ٶȱջ����Ƽ�����B����PWM
    flag_con();
    Limit(&Motor_A,&Motor_B);                                             //===PWM�޷�
    Load(Motor_A,Motor_B);

//	    lcd_showstr(20,0,"MA");
//	    lcd_showstr(20,1,"MB");
//	 	  lcd_showstr(20,2,"Left");
//		  lcd_showstr(20,3,"Right");
//	  	lcd_showstr(20,4,"TA");
//	    lcd_showstr(20,5,"TB");
//		  lcd_showstr(20,7,"TURN");

//      systick_delay_ms(1);
//		  lcd_showfloat(60,0,Motor_A,5,3);
//		  lcd_showfloat(60,1,Motor_B,5,3);
//		  lcd_showfloat(60,2,Encoder_Left,5,3);
//		  lcd_showfloat(60,3,Encoder_Right,5,3);
//		  lcd_showfloat(60,4,Target_A,5,3);
//		  lcd_showfloat(60,5,Target_B,5,3);
//		  lcd_showfloat(60,7,Turn,5,3);

//	    lcd_showint8(130,5,get_flag.prering);
//	  	lcd_showint8(130,6,get_flag.preringend);
//		  lcd_showint8(130,7,get_flag.ring);
//      lcd_showint8(130,7,get_flag.ringin);

}

/********************************************************************************
* Routine: Loop_333Hz
* Description:
* Param: NULL
* Return: NULL
* Notes:
**********************************************************************************/
static void Loop_333Hz(void)

{
    flag_get();
}

/********************************************************************************
* Routine: Loop_200Hz
* Description:
* Param: NULL
* Return: NULL
* Notes:
**********************************************************************************/
static void Loop_200Hz(void)
{

}

/********************************************************************************
* Routine: Loop_100Hz
* Description:
* Param: NULL
* Return: NULL
* Notes:
**********************************************************************************/
static void Loop_100Hz(void)
{

}

/********************************************************************************
* Routine: Loop_50Hz
* Description:
* Param: NULL
* Return: NULL
* Notes:
**********************************************************************************/
static void Loop_50Hz(void)
{

}

/********************************************************************************
* Routine: Loop_20Hz
* Description:
* Param: NULL
* Return: NULL
* Notes:
**********************************************************************************/
static void Loop_20Hz(void)
{

}

/********************************************************************************
* Routine: Loop_5Hz
* Description:
* Param: NULL
* Return: NULL
* Notes:
**********************************************************************************/
static void Loop_5Hz(void)
{

}

/********************************************************************************
* Routine: Loop_2Hz
* Description:
* Param: NULL
* Return: NULL
* Notes:
**********************************************************************************/
static void Loop_2Hz(void)
{

}

/********************************************************************************
* Routine: Loop_1Hz
* Description:
* Param: NULL
* Return: NULL
* Notes:
**********************************************************************************/
static void Loop_1Hz(void)
{

}

//ϵͳ�������ã�������ִͬ��Ƶ�ʵġ��̡߳�
static sched_task_t sched_tasks[] =
{
    {Loop_1000Hz,1000,  0, 0, 0},
    {Loop_500Hz , 500,  0, 0, 0},
    {Loop_333Hz , 333,  0, 0, 0},
    {Loop_200Hz , 200,  0, 0, 0},
    {Loop_100Hz , 100,  0, 0, 0},
    {Loop_50Hz  ,  50,  0, 0, 0},
    {Loop_20Hz  ,  20,  0, 0, 0},
    {Loop_5Hz   ,   5,  0, 0, 0},
    {Loop_2Hz   ,   2,  0, 0, 0},
    {Loop_1Hz   ,   1,  0, 0, 0},
};
//�������鳤�ȣ��ж��߳�����
#define TASK_NUM (sizeof(sched_tasks)/sizeof(sched_task_t))

/********************************************************************************
* Routine: Scheduler_Init
* Description:
* Param: void
* Return: void
* Notes:
**********************************************************************************/
void Scheduler_Init(void)
{
    uint8_t index = 0;
    //��ʼ�������
    for(index=0; index < TASK_NUM; index++)
    {
        //����ÿ���������ʱ������
        sched_tasks[index].interval_ticks = (uint16_t)(1000.0f/sched_tasks[index].rate_hz);
        //�������Ϊ1
        if(sched_tasks[index].interval_ticks < 1)
        {
            sched_tasks[index].interval_ticks = 1;
        }
    }
}

/********************************************************************************
* Routine: Scheduler_Run
* Description:
* Param: NULL
* Return: NULL
* Notes:
**********************************************************************************/
void Scheduler_Run(void)
{
    systime_ms++;
    uint8_t index = 0;
    uint32_t count = 0;
    //ѭ���ж������̣߳��Ƿ�Ӧ��ִ��

    for(index=0; index < TASK_NUM; index++)
    {
        count = TIM_GetCounter(TIM7);
        //�����жϣ������ǰʱ���ȥ��һ��ִ�е�ʱ�䣬���ڵ��ڸ��̵߳�ִ�����ڣ���ִ���߳�
        //ͬʱ�жϣ��������1msִ�����������㹻ʱ��ִ��������ִ�У��������������ִ��
        if(systime_ms - sched_tasks[index].last_run >= sched_tasks[index].interval_ticks && 1000-count >=sched_tasks[index].run_time)
        {
            //�����̵߳�ִ��ʱ�䣬������һ���ж�
            sched_tasks[index].last_run = systime_ms;
            //ִ���̺߳�����ʹ�õ��Ǻ���ָ��
            sched_tasks[index].task_func();
            //��¼�߳�ִ��ʱ��
            sched_tasks[index].run_time = TIM_GetCounter(TIM7) - count;
        }
    }
}

/********************************************************************************
* Routine: GetSysTimeMs
* Description:
* Param: void
* Return: uint64_t
* Notes:
**********************************************************************************/
uint64_t GetSysTimeMs(void)
{
    return systime_ms;
}





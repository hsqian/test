#ifndef __ALL_init_H
#define __ALL_init_H

#include "headfile.h"

void all_init(void);

#endif
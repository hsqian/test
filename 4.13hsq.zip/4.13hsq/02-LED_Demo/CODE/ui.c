#include "ui.h"

Key_index_struct const Key_table[21]=
{
    //��ǰ, ��һ������һ��, ȷ��
    {0, 3, 1, 4,(*menu1)},//һ�������һ��
    {1, 0, 2, 8,(*menu2)},//һ������ڶ���
    {2, 1, 3, 12,(*menu3)},//һ�����������
    {3, 2, 0, 16,(*menu4)},//һ�����������
    {4, 7, 5, 4,(*subMenu1_1)},//1���������һ��
    {5, 4, 6, 5,(*subMenu1_2)},//1��������ڶ���
    {6, 5, 7, 6,(*subMenu1_3)},//1�������������
    {7, 6, 4, 0,(*subMenu1_4)},//1�������������
    {8, 11, 9, 8,(*subMenu2_1)},//2���������һ��
    {9, 8, 10, 9,(*subMenu2_2)},//2��������ڶ���
    {10, 9, 11, 10,(*subMenu2_3)},//2�������������
    {11, 10, 8, 1,(*subMenu2_4)},//2�������������
    {12, 15, 13, 12,(*subMenu3_1)},//3���������һ��
    {13, 12, 14, 13,(*subMenu3_2)},//3��������ڶ���
    {14, 13, 15, 14,(*subMenu3_3)},//3�������������
    {15, 14, 12, 2,(*subMenu3_4)},//3�������������
    {16, 15, 17, 16,(*subMenu4_1)},//4���������һ��
    {17, 16, 18, 17,(*subMenu4_2)},//4��������ڶ���
    {18, 15, 19, 18,(*subMenu4_3)},//4�������������
    {19, 18, 16, 3,(*subMenu4_4)},//4�������������
};

u8 nowIndex = 0;
float static v_kp=0,v_ki=0,vel=0,t_kp=0,t_kd=0,r_kp=0;//pid���Ե�ֵ
u32 pid[6]= {0,0,0,0,0,0}; //pid����
static int clc=1;


void LCD_display(void)
{

    u8 key=0;

    key=KEY_Scan(0);
    flash_page_read(FLASH_SECTION_15,FLASH_PAGE_0,pid,32);
    switch(key)
    {
    case KEY2_PRES:
        lcd_clear(BLACK);
        nowIndex=Key_table[nowIndex].up_index;
        break;
    case KEY0_PRES:
        lcd_clear(BLACK);
        nowIndex=Key_table[nowIndex].next_index;
        break;
    case KEY1_PRES:
        lcd_clear(BLACK);
        nowIndex=Key_table[nowIndex].enter_index;
        break;
    }

    Key_table[nowIndex].operate();
}

void menu1(void)//�˵��б�
{
    lcd_showstr(20,0,"VELOCITY");
    lcd_showstr(20,2,"TURN");
    lcd_showstr(20,4,"menu3");
    lcd_showstr(20,6,"menu4");
    Draw_Circle(10,8,5,WHITE);
}
void menu2(void)//�˵��б�
{
    lcd_showstr(20,0,"VELOCITY");
    lcd_showstr(20,2,"TURN");
    lcd_showstr(20,4,"menu3");
    lcd_showstr(20,6,"menu4");
    Draw_Circle(10,40,5,WHITE);
}

void menu3(void)//�˵��б�
{
    lcd_showstr(20,0,"VELOCITY");
    lcd_showstr(20,2,"TURN");
    lcd_showstr(20,4,"menu3");
    lcd_showstr(20,6,"menu4");
    Draw_Circle(10,72,5,WHITE);
}
void menu4(void)//�˵��б�
{
    lcd_showstr(20,0,"VELOCITY");
    lcd_showstr(20,2,"TURN");
    lcd_showstr(20,4,"menu3");
    lcd_showstr(20,6,"menu4");
    Draw_Circle(10,104,5,WHITE);
}

//=======================�Ӳ˵�1==========================
void subMenu1_1(void)//�Ӳ˵��б�
{
    lcd_clear(BLACK);
    v_kp=pid[0];
    v_ki=pid[1];
    vel=pid[2];
    lcd_debug1(&v_kp,10,8,1);
}

void subMenu1_2(void)//�Ӳ˵��б�
{
    lcd_clear(BLACK);
    v_kp=pid[0];
    v_ki=pid[1];
    vel=pid[2];
    lcd_debug1(&v_ki,10,40,1);
}

void subMenu1_3(void)//�Ӳ˵��б�
{
    lcd_clear(BLACK);
    v_kp=pid[0];
    v_ki=pid[1];
    vel=pid[2];
    lcd_debug1(&vel,10,72,1);
}

void subMenu1_4(void)//�Ӳ˵��б�
{
    Draw_Circle(10,104,5,WHITE);
    lcd_showstr(20,0,"v_kp");
    lcd_showstr(20,2,"v_ki");
    lcd_showstr(20,4,"Vel");
    lcd_showstr(20,6,"exti");
    lcd_showfloat(60,0,v_kp,3,3);
    lcd_showfloat(60,2,v_ki/1000,3,3);
    lcd_showfloat(60,4,vel,3,3);
    v_kp=pid[0];
    v_ki=pid[1];
    vel=pid[2];
}
//======================�Ӳ˵�2===========================
void subMenu2_1(void)//�Ӳ˵��б�
{
    lcd_clear(BLACK);
    t_kp=pid[3];
    t_kd=pid[4];
    r_kp=pid[5];
    lcd_debug2(&t_kp,10,8,10);
}

void subMenu2_2(void)//�Ӳ˵��б�
{
    lcd_clear(BLACK);
    t_kp=pid[3];
    t_kd=pid[4];
    r_kp=pid[5];
    lcd_debug2(&t_kd,10,40,1);

}

void subMenu2_3(void)//�Ӳ˵��б�
{
    lcd_clear(BLACK);
    t_kp=pid[3];
    t_kd=pid[4];
    r_kp=pid[5];
    lcd_debug2(&r_kp,10,72,1);
}

void subMenu2_4(void)//�Ӳ˵��б�
{
    Draw_Circle(10,104,5,WHITE);
    lcd_showstr(20,0,"t_kp");
    lcd_showstr(20,2,"t_kd");
    lcd_showstr(20,4,"r_kp");
    lcd_showstr(20,6,"exti");
    lcd_showfloat(60,0,t_kp,4,3);
    lcd_showfloat(60,2,t_kd/1000,4,3);
    lcd_showfloat(60,4,r_kp,4,3);
    t_kp=pid[3];
    t_kd=pid[4];
    r_kp=pid[5];

}
//======================�Ӳ˵�3===========================
void subMenu3_1(void)//�Ӳ˵��б�
{
    lcd_showstr(20,0,"subMenu3_1");
    lcd_showstr(20,2,"subMenu3_2");
    lcd_showstr(20,4,"subMenu3_3");
    lcd_showstr(20,6,"exit");
    Draw_Circle(10,8,5,WHITE);
}

void subMenu3_2(void)//�Ӳ˵��б�
{
    lcd_showstr(20,0,"subMenu3_1");
    lcd_showstr(20,2,"subMenu3_2");
    lcd_showstr(20,4,"subMenu3_3");
    lcd_showstr(20,6,"exit");
    Draw_Circle(10,40,5,WHITE);
}

void subMenu3_3(void)//�Ӳ˵��б�
{
    lcd_showstr(20,0,"subMenu3_1");
    lcd_showstr(20,2,"subMenu3_2");
    lcd_showstr(20,4,"subMenu3_3");
    lcd_showstr(20,6,"exit");
    Draw_Circle(10,72,5,WHITE);
}

void subMenu3_4(void)//�Ӳ˵��б�
{
    lcd_showstr(20,0,"subMenu3_1");
    lcd_showstr(20,2,"subMenu3_2");
    lcd_showstr(20,4,"subMenu3_3");
    lcd_showstr(20,6,"exit");
    Draw_Circle(10,104,5,WHITE);
}

void subMenu4_1(void)//�Ӳ˵��б�
{
    lcd_showstr(20,0,"watch");
    lcd_showstr(20,2,"subMenu4_2");
    lcd_showstr(20,4,"START");
    lcd_showstr(20,6,"exit");
    lcd_watch(10,8);
}

void subMenu4_2(void)//�Ӳ˵��б�
{
    lcd_showstr(20,0,"watch");
    lcd_showstr(20,2,"subMenu4_2");
    lcd_showstr(20,4,"START");
    lcd_showstr(20,6,"exit");
    Draw_Circle(10,40,5,WHITE);
}

void subMenu4_3(void)//�Ӳ˵��б�
{
    char flag=1;
    vu8 key=0;

    lcd_showstr(20,0,"watch");
    lcd_showstr(20,2,"subMenu4_2");
    lcd_showstr(20,4,"START");
    lcd_showstr(20,6,"exit");
    Draw_Circle(10,72,5,WHITE);

    while(flag)
    {
        key=KEY_Scan(1);
        switch(key)
        {
        case KEY0_PRES:
            flag=0;
            nowIndex=Key_table[nowIndex].next_index;
            systick_delay_ms(100);
            break;
        case KEY2_PRES:
            flag=0;
            nowIndex=Key_table[nowIndex].up_index;
            systick_delay_ms(100);
            break;
        case KEY1_PRES:
            flag=0;
            get_flag.lcd=0;
            break;
        }
        v_kp=pid[0];
        v_ki=pid[1];
        vel=pid[2];
        t_kp=pid[3];
        t_kd=pid[4];
        r_kp=pid[5];

        Velocity_KP=v_kp;
        Velocity_KI=v_ki/1000;
        Velocity=vel;
        Turn_KP=t_kp;
        Turn_KD=t_kd/1000;
        Ring_KP=r_kp;
        Velocity_MAX=vel;
    }
    lcd_clear(BLACK);
}

void subMenu4_4(void)//�Ӳ˵��б�
{
    lcd_showstr(20,0,"watch");
    lcd_showstr(20,2,"subMenu4_2");
    lcd_showstr(20,4,"START");
    lcd_showstr(20,6,"exit");
    Draw_Circle(10,104,5,WHITE);
}

void ring(int x,int y)
{
    Draw_Circle(x,y,5,WHITE);
    systick_delay_ms(5);
    Draw_Circle(x,y,5,BLACK);
    systick_delay_ms(5);
}
void lcd_debug1(float *kx,int x ,int y ,float add)
{
    int fir=1,sec=0,key;

    lcd_showstr(20,0,"v_kp");
    lcd_showstr(20,2,"v_ki");
    lcd_showstr(20,4,"Vel");
    lcd_showstr(20,6,"exti");
    lcd_showfloat(60,0,v_kp,4,3);
    lcd_showfloat(60,2,v_ki/1000,4,3);
    lcd_showfloat(60,4,vel,4,3);

    while(fir)
    {
        ring(x,y);
        key=KEY_Scan(0);
        switch(key)
        {
        case KEY0_PRES:
            fir=0;
            nowIndex=Key_table[nowIndex].next_index;
            systick_delay_ms(100);
            break;
        case KEY2_PRES:
            fir=0;
            nowIndex=Key_table[nowIndex].up_index;
            systick_delay_ms(100);
            break;
        case KEY1_PRES:
            sec=1;
            systick_delay_ms(100);
            break;
        }
        while(sec)
        {
            lcd_showfloat(60,0,v_kp,4,3);
            lcd_showfloat(60,2,v_ki/1000,4,3);
            lcd_showfloat(60,4,vel,4,3);
            Draw_Circle(x,y,5,WHITE);

            key=KEY_Scan(1);

            switch(key)
            {
            case KEY0_PRES:
                *kx=*kx-add;
                systick_delay_ms(10);
                break;
            case KEY2_PRES:
                *kx=*kx+add;
                systick_delay_ms(10);
                break;
            case KEY1_PRES:
                sec=0;
                fir=0;
                pid[0]=v_kp;
                pid[1]=v_ki;
                pid[2]=vel;
                Velocity_KP=v_kp;
                Velocity_KI=v_ki/1000;
                Velocity=vel;
                flash_page_program(FLASH_SECTION_15,FLASH_PAGE_0,pid,32);//����pid��ֵ
                systick_delay_ms(10);
                break;
            }
        }
    }
}

void lcd_debug2(float *kx,int x ,int y ,float add)
{
    int fir=1,sec=0,key;

    lcd_showstr(20,0,"t_kp");
    lcd_showstr(20,2,"t_kd");
    lcd_showstr(20,4,"r_kp");
    lcd_showstr(20,6,"exti");
    lcd_showfloat(60,0,t_kp,4,3);
    lcd_showfloat(60,2,t_kd/1000,4,3);
    lcd_showfloat(60,4,r_kp,4,3);
    //----------����ҳ��ѡ����/�£�
    while(fir)
    {
        ring(x,y);
        key=KEY_Scan(0);
        switch(key)
        {
        case KEY0_PRES:
            fir=0;
            nowIndex=Key_table[nowIndex].next_index;
            systick_delay_ms(100);
            break;
        case KEY2_PRES:
            fir=0;
            nowIndex=Key_table[nowIndex].up_index;
            systick_delay_ms(100);
            break;
        case KEY1_PRES:
            sec=1;
            systick_delay_ms(100);
            break;
        }
        //----------����
        while(sec)
        {
            lcd_showfloat(60,0,t_kp,4,3);
            lcd_showfloat(60,2,t_kd/1000,4,3);
            lcd_showfloat(60,4,r_kp,4,3);
            Draw_Circle(x,y,5,WHITE);

            key=KEY_Scan(1);

            switch(key)
            {
            case KEY0_PRES:
                *kx=*kx-add;
                systick_delay_ms(10);
                break;
            case KEY2_PRES:
                *kx=*kx+add;
                systick_delay_ms(10);
                break;
            case KEY1_PRES:
                sec=0;
                fir=0;
                pid[3]=t_kp;
                pid[4]=t_kd;
                pid[5]=r_kp;
                Turn_KP=t_kp;
                Turn_KD=t_kd/1000;
                Ring_KP=r_kp;
                flash_page_program(FLASH_SECTION_15,FLASH_PAGE_0,pid,32);//����pid��ֵ
                systick_delay_ms(10);
                break;
            }
        }
    }
}

void lcd_watch(int x,int y)
{
    int fir=1,sec=0,key;

    while(fir)
    {
        ring(x,y);
        key=KEY_Scan(0);
        switch(key)
        {
        case KEY0_PRES:
            fir=0;
            nowIndex=Key_table[nowIndex].next_index;
            systick_delay_ms(100);
            break;
        case KEY2_PRES:
            fir=0;
            nowIndex=Key_table[nowIndex].up_index;
            systick_delay_ms(100);
            break;
        case KEY1_PRES:
            sec=1;
            systick_delay_ms(100);
            break;
        }
        clc=1;
        while(sec)
        {
            adc_watch();
            key=KEY_Scan(1);
            if(key!=0)
            {
                fir=0;
                sec=0;
                lcd_clear(BLACK);
            }
        }

    }

}

void adc_watch(void)
{

    if(clc)
    {
        lcd_clear(BLACK);
        clc=0;
    }
    flag_get();
    Get_RC();
    Kinematic_Analysis(Velocity,Turn);

    systick_delay_ms(1);
    lcd_showstr(0,0,"RR");
    lcd_showstr(0,1,"R");
    lcd_showstr(0,2,"RM");
    lcd_showstr(0,3,"LM");
    lcd_showstr(0,4,"L");
    lcd_showstr(0,5,"LL");
    lcd_showstr(130,0,"pre");
    lcd_showstr(130,2,"rin");
    lcd_showstr(130,4,"in");
    lcd_showstr(130,6,"out");
    lcd_showstr(0,7,"turn");
    lcd_showstr(0,6,"A");
    lcd_showstr(50,6,"B");
    lcd_showstr(90,0,"str");
    lcd_showfloat(120,1,get_flag.prering,1,1);
    lcd_showfloat(120,3,get_flag.ring,1,1);
    lcd_showfloat(120,5,get_flag.ringin,1,1);
    lcd_showfloat(120,7,get_flag.ringout,1,1);
    lcd_showfloat(90,1,get_flag.straight,1,1);
    lcd_showfloat(20,0,ADC_RR,3,3);
    lcd_showfloat(20,1,ADC_R,3,3);
    lcd_showfloat(20,2,ADC_RM,3,3);
    lcd_showfloat(20,3,ADC_LM,3,3);
    lcd_showfloat(20,4,ADC_L,3,3);
    lcd_showfloat(20,5,ADC_LL,3,3);
    lcd_showfloat(35,7,Turn,4,3);
    lcd_showint8(10,6,Target_A);
    lcd_showint8(60,6,Target_B);
}
#ifndef __CONTROL_H
#define __CONTROL_H
#include "headfile.h"

#define PI 3.14159265



void Kinematic_Analysis(float velocity,float turn);
void TIM1_UP_IRQHandler(void) ;
int Incremental_PI_A (int Encoder,int Target);
int Incremental_PI_B (int Encoder,int Target);
void Get_RC(void);
void my_adcfilter_get(void);
void flag_get(void);
void flag_con(void);

#endif
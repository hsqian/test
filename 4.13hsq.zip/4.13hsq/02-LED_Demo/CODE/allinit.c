#include "allinit.h"

void all_init(void)
{
    myadc_init();
    Encoder_Init();
    Motor_PWM_Init();
    lcd_init();
    Scheduler_Init();
    KEY_Init();

//	uart_init(UART_1,115200,UART1_TX_A09,UART1_RX_A10);

//------��־λ
    get_flag.lcd=1;

    get_flag.car_run=0;
    get_flag.outstop=0;
    get_flag.locked_rotor=0;

    get_flag.turnL=0;
    get_flag.turnR=0;
    get_flag.straight=0;

    get_flag.prering=0;
    get_flag.ring=0;
    get_flag.ringin=0;
    get_flag.ringout=0;
}
#include "test.h"


//void test(int TESTx)
//{
//	switch TESTx
//	{
//		case 1:
//		case 2��
//		case 3:
//		case 4��
//		case 5:
//		case 6��
//	}
//}
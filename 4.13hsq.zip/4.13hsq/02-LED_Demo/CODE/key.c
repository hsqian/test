#include "key.h"

void KEY_Init(void)
{
    gpio_init(G2,GPI,GPIO_HIGH,GPI_PULL_UP);
    gpio_init(G3,GPI,GPIO_HIGH,GPI_PULL_UP);
    gpio_init(G4,GPI,GPIO_HIGH,GPI_PULL_UP);
    gpio_init(G5,GPI,GPIO_HIGH,GPI_PULL_UP);
    gpio_init(G6,GPI,GPIO_HIGH,GPI_PULL_UP);
}

u8 KEY_Scan(u8 mode)
{
    static u8 key_up=1;//�������ɿ���־

    if(mode)key_up=1;  //֧������
    if(key_up&&(KEY3==0||KEY4==0||KEY5==0))
    {
        systick_delay_us(50000);
        key_up=0;
        if(KEY3==0)return KEY0_PRES;
        else if(KEY4==0)return KEY1_PRES;
        else if(KEY5==0)return KEY2_PRES;
    } else if(KEY3==1&&KEY4==1&&KEY5==1)key_up=1;
    return 0;// �ް�������
}

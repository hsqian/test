#include "nomalize.h"

float nomal(float data , int ADCGET_MAX)
{
    float temp=0,numback=0;
    temp=data/ADCGET_MAX;
    numback=temp*100;

    if(numback>=NUM_MAX)
        numback=NUM_MAX;

    if(numback<=NUM_MIN)
        numback=NUM_MIN;

    return numback;
}
